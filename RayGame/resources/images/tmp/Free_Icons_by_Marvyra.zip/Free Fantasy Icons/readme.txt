Hi there, you're awesome! :)

Thank you for supporting me by downloading my Free Icons!
--------------------------------------------

Feel free to use these non-commercial or commercial. All I ask in return is for you to credit me for them. Thanks! :)

You may NOT redistribute these or resell them.

If you have any questions please leave a comment.

--------------------------------------------

I hope you enjoy them and good luck!

Marvyra

