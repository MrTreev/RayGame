Hey thanks for purchasing! If you have some problem 
or petition contact me by:
Instagram: @underpixelarted
Gmail: anders0nfern4ndez@gmail.com